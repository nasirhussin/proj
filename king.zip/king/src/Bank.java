import java.util.Date;  
  
public class Bank 
{  
private int accno,balance;  
private String branch;  
 
public Bank() { }
 
  
public Bank(int accno, int balance, String branch) {
	super();
	this.accno = accno;
	this.balance = balance;
	this.branch = branch;
}



@Override
public String toString() {
	return "Bank [accnumber=" + accno + ", balance=" + balance + ", branch=" + branch + "]";
}



 
}  