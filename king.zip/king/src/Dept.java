public class Dept {  
 
private String deptname,loc,designation;  

public Dept() { }
  

public Dept(String deptname, String loc, String designation) {
	super();
	this.deptname = deptname;
	this.loc = loc;
	this.designation = designation;
}


@Override
public String toString() {
	return "Dept [deptname=" + deptname + ", location=" + loc + ", designation=" + designation + "]";
}





  
}  