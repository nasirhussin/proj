import java.util.Iterator;  
import java.util.Map;  
import java.util.Set;  
import java.util.Map.Entry;  

public class Customer {  
	private int id;  
	private String name,dept,bankname;  
	private Map<Bank,Dept> bank;  

	public Customer() {}  
	
	public Customer(int id, String name, String dept,String bankname, Map<Bank, Dept> bank) 
	{
		super();
		this.id = id;
		this.name = name;
		this.dept = dept;
		this.bankname=bankname;
		this.bank = bank;
	}

	public void displayInfo()
	{  
		System.out.println("Customer  id:"+id);  
		System.out.println("Customer name:"+name); 
		System.out.println("Customer bankname:"+bankname); 
		System.out.println(" \n");
		Set<Entry<Bank, Dept>> set=bank.entrySet();  
		Iterator<Entry<Bank, Dept>> itr=set.iterator();  
		while(itr.hasNext())
		{  
			Entry<Bank, Dept> entry=itr.next();  
			Bank ans=entry.getKey();  
			Dept user=entry.getValue();  
			System.out.println("Bank Information:"); 
			System.out.println(ans);  
			System.out.println("\n"); 
			System.out.println("Departmet Information:");   
			System.out.println(user);  
		}  
	}  
}  